#!/bin/bash
sudo rm -f /var/lib/dpkg/updates/*
sudo dpkg --configure -a
sudo apt-get update
sudo apt-get install -f
sudo apt install -y apache2 php7.4 libapache2-mod-php7.4 php7.4-cli php7.4-mysql php7.4-gd php7.4-xml php7.4-curl mysql-server unzip python3 python3-pip
sudo systemctl start apache2
sudo systemctl start mysql

show_bot_token_instructions() {
    echo "Инструкция по получению токена бота:"
    echo "1. Откройте Telegram и найдите @BotFather"
    echo "2. Отправьте команду /newbot"
    echo "3. Следуйте инструкциям для создания нового бота"
    echo "4. После создания бота, BotFather предоставит вам токен"
    echo "5. Скопируйте этот токен и вставьте его ниже"
    echo ""
    echo "Instructions for obtaining a bot token:"
    echo "1. Open Telegram and search for @BotFather"
    echo "2. Send the /newbot command"
    echo "3. Follow the instructions to create a new bot"
    echo "4. After creating the bot, BotFather will provide you with a token"
    echo "5. Copy this token and paste it below"
    echo ""
}

read -p "Введите имя базы данных (ENTER NAME DATABASE): " db_name
read -p "Введите имя пользователя базы данных (ENTER USERNAME): " db_user
read -p "Введите пароль для пользователя базы данных (ENTER PASSWORD): " db_password

show_bot_token_instructions
read -p "Введите токен бота (ENTER BOT TOKEN): " bot_token


admin_panel_path="/var/www/html/$(openssl rand -base64 12 | tr -dc 'a-zA-Z0-9' | cut -c1-16)"
echo "Каталог админ-панели (catalog admin panel): $admin_panel_path"
sudo mysql -e "CREATE DATABASE IF NOT EXISTS $db_name;"
sudo mysql -e "CREATE USER IF NOT EXISTS '$db_user'@'%' IDENTIFIED BY '$db_password';"
sudo mysql -e "GRANT ALL PRIVILEGES ON $db_name.* TO '$db_user'@'%';"
sudo mysql -e "ALTER USER '$db_user'@'%' IDENTIFIED WITH mysql_native_password BY '$db_password';"
sudo mysql -e "FLUSH PRIVILEGES;"
if [ -f /etc/mysql/mysql.conf.d/mysqld.cnf ]; then
    sudo sed -i 's/bind-address.*=.*/bind-address = 0.0.0.0/' /etc/mysql/mysql.conf.d/mysqld.cnf
else
    echo "Файл конфигурации MySQL не найден. Пропускаем изменение bind-address. (MySQL configuration file was not found. Skip changing bind-address)"
fi
sudo systemctl restart mysql
sudo mkdir -p /var/www/html
echo "Options -Indexes" | sudo tee /var/www/html/.htaccess
echo "<IfModule mod_headers.c>" | sudo tee -a /var/www/html/.htaccess
echo "    Header set Access-Control-Allow-Origin \"*\"" | sudo tee -a /var/www/html/.htaccess
echo "</IfModule>" | sudo tee -a /var/www/html/.htaccess
sudo mkdir -p $admin_panel_path
if [ -f panel.zip ]; then
    sudo unzip -o panel.zip -d $admin_panel_path
else
    echo "Файл panel.zip не найден. Пропускаем распаковку. (The panel.zip file was not found. Skip unpacking.)"
fi

bot_path="$admin_panel_path/botrg"
sudo mkdir -p $bot_path

if [ -f bot.zip ]; then
    sudo unzip -o bot.zip -d $bot_path
else
    echo "Файл bot.zip не найден. Пропускаем распаковку бота. (The bot.zip file was not found. Skip unpacking the bot.)"
fi

sudo pip3 install telebot pymysql mysql-connector-python

sudo tee $bot_path/config.py > /dev/null << EOF
import json
import os

BOT_TOKEN = '$bot_token'

DB_CONFIG = {
    'host': 'localhost',
    'user': '$db_user',
    'password': '$db_password',
    'database': '$db_name'
}

STATE_FILE = 'bot_state.json'

AUTHORIZED_USERS_FILE = 'authorized_users.json'

def load_authorized_users():
    if os.path.exists(AUTHORIZED_USERS_FILE):
        with open(AUTHORIZED_USERS_FILE, 'r') as f:
            return json.load(f)
    return []

def save_authorized_users(users):
    with open(AUTHORIZED_USERS_FILE, 'w') as f:
        json.dump(users, f)

AUTHORIZED_USERS = load_authorized_users()
EOF

sudo chown -R www-data:www-data /var/www
sudo chmod -R 755 $admin_panel_path
sudo mkdir -p $admin_panel_path/includes
sudo tee $admin_panel_path/includes/config.php > /dev/null << EOF
<?php
// config.php
\$host = 'localhost';
\$dbUsername = '$db_user';
\$dbPassword = '$db_password';
\$dbName = '$db_name';

// Создаем подключение к базе данных
\$db = new mysqli(\$host, \$dbUsername, \$dbPassword, \$dbName);

// Проверяем подключение
if (\$db->connect_error) {
    die("Ошибка подключения: " . \$db->connect_error);
}
?>
EOF
if [ -f database_setup.sql ]; then
    sudo mysql $db_name < database_setup.sql
else
    echo "Файл database_setup.sql не найден. Пропускаем импорт базы данных. (The database_setup.sql file was not found. Skip the database import.)"
fi
(crontab -l 2>/dev/null; echo "*/3 * * * * /usr/bin/php $admin_panel_path/includes/updatecron.php") | crontab -
(crontab -l 2>/dev/null; echo "*/4 * * * * /usr/bin/php $admin_panel_path/includes/update.php") | crontab -
(crontab -l 2>/dev/null; echo "0 0 * * 0 /usr/bin/certbot renew --quiet") | crontab -
server_ip=$(hostname -I | awk '{print $1}')
admin_panel_folder=$(basename $admin_panel_path)

# Настраиваем права доступа
sudo chown -R www-data:www-data $bot_path
sudo chmod -R 755 $bot_path

# Добавляем запуск бота в crontab для автозапуска при перезагрузке
(crontab -l 2>/dev/null; echo "@reboot /usr/bin/python3 $bot_path/main.py >> $bot_path/bot.log 2>&1") | crontab -

# Запускаем бота в фоновом режиме
echo "Запуск Telegram бота..."
sudo -u www-data nohup python3 $bot_path/main.py > $bot_path/bot.log 2>&1 &

# Проверяем, запустился ли бот
sleep 5
if pgrep -f "$bot_path/main.py" > /dev/null
then
    echo "Telegram бот успешно запущен в фоновом режиме."
else
    echo "Не удалось запустить Telegram бота. Проверьте лог-файл: $bot_path/bot.log"
fi

echo "Настройка завершена. Теперь вы можете перейти к регистрации в админ-панели. (The configuration is complete. Now you can proceed to registration in the admin panel.)"
echo "Путь к админ-панели (Path to admin panel): $admin_panel_path"
echo "Путь к Telegram боту (Path to Telegram bot): $bot_path"
echo "Лог-файл бота (Bot log file): $bot_path/bot.log"
echo ""
echo "Дополнительная информация для установки веб сокет сервера (Additional information for installing web socket server):"
echo "Путь к админ панели (URL to admin panel): http://$server_ip/$admin_panel_folder"
echo "db user (database username): $db_user"
echo "db password (database password): $db_password"
echo "db name (database name): $db_name"
