#!/bin/bash
sudo apt update
sudo apt install -y apache2 php7.4 libapache2-mod-php7.4 php7.4-cli php7.4-mysql php7.4-gd php7.4-xml php7.4-curl nodejs npm php-curl curl
curl -sL https://deb.nodesource.com/setup_14.x | sudo -E bash -
sudo apt-get install -y nodejs
sudo a2enmod headers proxy_http proxy proxy_wstunnel rewrite remoteip
sudo systemctl restart apache2
read -p "Введите доменное имя вашего сайта (enter domain name for web socket): " domain_name
read -p "Введите email для SSL-сертификата (enter email for ssl *u can random mail*): " email_address
INITIAL_DIR=$(pwd)
sudo mkdir -p /var/www/$domain_name
sudo chown -R www-data:www-data /var/www/$domain_name
read -p "Введите имя папки для общих файлов (enter name folder - any): " common_dir
sudo mkdir -p /var/www/$domain_name/$common_dir
cat << EOF | sudo tee /etc/apache2/sites-available/$domain_name.conf
<VirtualHost *:80>
    ServerAdmin $email_address
    ServerName $domain_name
    DocumentRoot /var/www/$domain_name

    <Directory /var/www/$domain_name/$common_dir>
        Order deny,allow
        Deny from all
    </Directory>

    <Directory /var/www/$domain_name>
        Options Indexes FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>

    RewriteEngine On
    RewriteCond %{HTTPS} off
    RewriteRule ^ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]

    ErrorLog \${APACHE_LOG_DIR}/${domain_name}_error.log
    CustomLog \${APACHE_LOG_DIR}/${domain_name}_access.log combined
</VirtualHost>
EOF
sudo a2ensite $domain_name.conf
sudo systemctl reload apache2
sudo apt install -y certbot python3-certbot-apache
sudo certbot --apache -d $domain_name --non-interactive --agree-tos -m $email_address
cat << EOF | sudo tee /etc/apache2/sites-available/$domain_name-le-ssl.conf
<IfModule mod_ssl.c>
<VirtualHost *:443>
    ServerAdmin $email_address
    ServerAlias $domain_name
    DocumentRoot /var/www/$domain_name

    SSLProxyEngine on
    ProxyPreserveHost On

    <Directory /var/www/$domain_name/$common_dir>
        Order deny,allow
        Deny from all
    </Directory>

    <Directory /var/www/$domain_name>
        Options Indexes FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>

    ProxyPass "/$common_dir" "ws://localhost:8098/"
    ProxyPassReverse "/$common_dir" "ws://localhost:8098/"

    RemoteIPHeader X-Real-IP

    ErrorLog \${APACHE_LOG_DIR}/${domain_name}_ssl_error.log
    CustomLog \${APACHE_LOG_DIR}/${domain_name}_ssl_access.log combined

    SSLCertificateFile /etc/letsencrypt/live/$domain_name/fullchain.pem
    SSLCertificateKeyFile /etc/letsencrypt/live/$domain_name/privkey.pem
    Include /etc/letsencrypt/options-ssl-apache.conf
</VirtualHost>
</IfModule>
EOF

sudo systemctl restart apache2

# Установка зависимостей Node.js
cd /var/www/$domain_name/$common_dir
npm install ws mysql mysql2 fs https uglify-js axios abab express body-parser cors async-mutex redis
sudo npm install -g pm2
cd "$INITIAL_DIR"

# Добавление задачи в crontab для обновления сертификата
(crontab -l 2>/dev/null; echo "0 0 * * 0 /usr/bin/certbot renew --quiet") | crontab -

# Запрос данных для конфигурации базы данных
read -p "Введите IP-адрес базы данных админ-панели / Enter the admin panel database IP address: " db_ip
read -p "Введите имя пользователя базы данных / Enter the database username: " db_user
read -p "Введите пароль базы данных / Enter the database password: " db_password
read -p "Введите имя базы данных / Enter the database name: " db_name
read -p "Введите URL админ-панели / Enter the admin panel URL (например/for example, http://192.168.1.100/adminpanel): " admin_panel_url

echo "Текущая директория:"
pwd
echo "Содержимое директории:"
ls -la

# Получение полного пути к директории скрипта
SCRIPT_DIR="$INITIAL_DIR"
echo "Директория скрипта: $SCRIPT_DIR"

# Проверка наличия файла wb.js
if [ ! -f "$SCRIPT_DIR/wb.js" ]; then
    echo "Файл wb.js не найден в директории $SCRIPT_DIR"
    echo "Убедитесь, что файл wb.js находится в той же директории, что и скрипт установки."
    exit 1
fi

# Проверка прав доступа
if [ ! -r "$SCRIPT_DIR/wb.js" ]; then
    echo "Нет прав на чтение файла $SCRIPT_DIR/wb.js"
    echo "Пожалуйста, проверьте права доступа к файлу."
    exit 1
fi

echo "Файл wb.js найден и доступен для чтения."

# Замена значений в файле wb.js
sed -i "s|host: 'ip admin panel db'|host: '$db_ip'|g" "$SCRIPT_DIR/wb.js"
sed -i "s|user: 'user admin panel db'|user: '$db_user'|g" "$SCRIPT_DIR/wb.js"
sed -i "s|password: 'password admin panel db'|password: '$db_password'|g" "$SCRIPT_DIR/wb.js"
sed -i "s|database: 'name admin panel db'|database: '$db_name'|g" "$SCRIPT_DIR/wb.js"
sed -i "s|https://site.com/adminpanel|$admin_panel_url|g" "$SCRIPT_DIR/wb.js"

# Копирование обновленного файла wb.js в директорию сайта
sudo cp "$SCRIPT_DIR/wb.js" /var/www/$domain_name/$common_dir/

# Установка прав на файлы
sudo chown -R www-data:www-data /var/www/$domain_name

echo "Установка завершена. Файл wb.js обновлен и скопирован в директорию $common_dir."
pm2 start /var/www/$domain_name/$common_dir/wb.js
pm2 save
pm2 startup
sudo env PATH=$PATH:/usr/bin /usr/lib/node_modules/pm2/bin/pm2 startup systemd -u $USER --hp /home/$USER

# Вывод информации о URL
echo "========================================="
echo "Установка успешно завершена!"
echo "URL WEB SOCKET: wss://$domain_name/$common_dir"
echo "Admin Panel URL: $admin_panel_url/login.php"
echo "========================================="